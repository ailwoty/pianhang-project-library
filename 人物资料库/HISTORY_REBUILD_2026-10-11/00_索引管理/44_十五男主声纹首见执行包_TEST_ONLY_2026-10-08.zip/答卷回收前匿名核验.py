#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""《偏航》声纹匿名答卷收取前质检，TEST_ONLY。无答案密钥、不计算人物命中。
文件使用说明：只验证匿名答卷的基础字段、题号、卷次、非泄漏声明和覆盖率。
新增原因：现有43号管理员计分工具不可发送读者且不负责逐人覆盖完整性。
边界：无真实读者CSV时仅可校验空白模板；不能称已收卷、已通过或发现真人成绩。
依赖：41/42号无答案卷与43号管理员评分字段接口；不替代38号作者档。
用法：python3 答卷回收前匿名核验.py --template V150_首见个人答卷_空白.csv --set V
      python3 答卷回收前匿名核验.py --responses 某个真实回收.csv --set V
禁止误用：工具无法证明受试者身份、是否真正首见或谁在现场提供帮助；该信息要靠招募与记录治理。
变更记录：2026-10-08 第54—63项首次建立，仅作读者端回收准备。
"""
import argparse, csv, json
from collections import Counter
from pathlib import Path
ROLES={'谢闻铎','秦照野','裴沉川','容既白','周妄生','陆知衡','闻淮止','顾晏深','祁慎修','沈稷','霍岑','江叙澄','梁暮寒','许泊言','段祈舟','无法判断','UNSURE','不确定'}
COLS=['tester_id','reader_group','item_id','set_version','top1','top2','confidence','seen_before','cue_leak_flag','reason','order_id']
LENS={'V':150,'C':18};VERS={'V':'V150_FROZEN_20261008','C':'C18_FROZEN_20261008'}

def validate(path, kind, blank_template=False):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:
        rd=csv.DictReader(f)
        if rd.fieldnames != COLS:raise ValueError('CSV表头不匹配，要求完全按模板列顺序：'+','.join(COLS))
        rows=list(rd)
    expected={f'{kind}{i:03d}' if kind=='V' else f'{kind}{i:02d}' for i in range(1,LENS[kind]+1)}
    found=[r['item_id'] for r in rows]
    if len(rows)!=len(expected) or set(found)!=expected or len(found)!=len(set(found)):
        raise ValueError(f'该文件须保留{len(expected)}个不同题号，且不可混入其他卷或删掉未答题')
    valid,missing,unsure,seen,leaked=0,0,0,0,0
    names=set();groups=set();orders=set()
    for r in rows:
        id=r['item_id']
        if r['set_version']!=VERS[kind]:raise ValueError(id+' 的set_version与冻结卷不一致')
        if blank_template:
            if any(r[k].strip() for k in COLS if k not in ('item_id','set_version')):
                raise ValueError('空白卷混入个人信息或预填答案：'+id)
            continue
        for k in ('tester_id','reader_group','order_id','seen_before','cue_leak_flag'):
            if not r[k].strip():raise ValueError(id+' 缺少必填字段：'+k)
        if r['seen_before'] not in ('true','false') or r['cue_leak_flag'] not in ('true','false'):
            raise ValueError(id+' 的泄漏标记必须是true或false')
        names.add(r['tester_id']);groups.add(r['reader_group']);orders.add(r['order_id'])
        a=r['top1'].strip();b=r['top2'].strip();c=r['confidence'].strip()
        if a and a not in ROLES:raise ValueError(id+' 的top1非法')
        if b and b not in ROLES:raise ValueError(id+' 的top2非法')
        if a and b and a==b:raise ValueError(id+' 的前两选择相同')
        if a and (c not in {'1','2','3','4','5'}):raise ValueError(id+' 缺少合法置信度')
        if not a and (b or c):raise ValueError(id+' 未答第一候选却填了第二候选或置信度')
        if r['seen_before']=='true':seen+=1
        elif r['cue_leak_flag']=='true':leaked+=1
        elif not a:missing+=1
        else:
            valid+=1
            if a in {'无法判断','UNSURE','不确定'}:unsure+=1
    if not blank_template and (len(names)!=1 or len(groups)!=1 or len(orders)!=1):
        raise ValueError('此模板只允许同一名匿名读者、一个分组和同一题序；跨人合并留给管理员')
    out={'status':'BLANK_TEMPLATE_VERIFIED' if blank_template else 'RESPONSE_INTAKE_CHECK_ONLY_NOT_A_READER_SCORE',
         'set':kind,'total_question_rows':len(rows),'valid_first_exposure_answer_rows':valid,
         'missing_or_blank':missing,'unsure_count_in_valid':unsure,'seen_before_excluded':seen,
         'cue_leak_excluded_after_seen':leaked,'has_personal_identity_verification':False,
         'has_recognition_accuracy':False}
    return out

def main():
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--template');g.add_argument('--responses');p.add_argument('--set',required=True,choices=['V','C'])
    a=p.parse_args();v=validate(a.template or a.responses,a.set,blank_template=bool(a.template))
    print(json.dumps(v,ensure_ascii=False,indent=2))
if __name__=='__main__':
    try:main()
    except (ValueError,OSError) as e:
        print('INTAKE_ERROR: '+str(e),file=__import__('sys').stderr)
        raise SystemExit(2)
